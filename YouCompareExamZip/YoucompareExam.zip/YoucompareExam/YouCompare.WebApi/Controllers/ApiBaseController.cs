﻿using System.Web.Http;
using YouCompare.Data.Contracts;

namespace YouCompare.WebApi.Controllers
{
    public class ApiBaseController : ApiController
    {
        public IUnitOfWorks Uow { get; set; }
    }
}