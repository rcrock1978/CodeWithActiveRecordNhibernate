﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Web.Http;
using YouCompare.Data;
using YouCompare.Data.Contracts;
using YouCompare.Model;

namespace YouCompare.WebApi.Controllers
{
    public class CustomersController : ApiBaseController
    {

        public CustomersController(IUnitOfWorks uow)
        {
            Uow = uow;
        }
        // GET api/<controller>
        public IEnumerable<Customer> Get()
        {
            return DtoCustomers.GetAllCustomers(Uow);
        }

        // GET api/<controller>/5
        public Customer Get(int id)
        {
            return DtoCustomers.GetCustomerById(Uow, id);
        }

        // POST api/<controller>
        public void Post(List<string> value)
        {
            Int32 i = 0;
            Customer newCustomer = new Customer()
            {
                Address = value[0],
                City = value[1],
                CompanyName = value[2],
                ContactName = value[3],
                Country = DtoCustomers.GetCountry(Uow,Int32.Parse(value[4])),
                Phone = value[6],
                PostalCode = Int32.Parse(value[7]),
                Region = DtoCustomers.GetRegion(Uow,Int32.Parse(value[8]))
            };
            DtoCustomers.NewCustomer(Uow, newCustomer);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
            //Customer customer = new Customer()
            //{

            //    Address = value[]
            //};
            //DtoCustomers.SaveCustomer();
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }

    [Serializable]
    [DataContract(IsReference = true)]
    public static class DtoCustomers
    {
        public static IEnumerable<Customer> GetAllCustomers(IUnitOfWorks uow)
        {
            return uow.Customers.getAll();
        }

        public static Customer GetCustomerById(IUnitOfWorks uow, int id)
        {
            return uow.Customers.getById(id);
        }

        public static void SaveCustomer(IUnitOfWorks uow, Customer customer)
        {
            uow.Customers.update(customer);
        }

        public static void NewCustomer(IUnitOfWorks uow, Customer customer)
        {
            uow.Customers.add(customer);
        }

        public static void DeleteCustomer(IUnitOfWorks uow, int id)
        {
            uow.Customers.delete(id);
        }

        public static Country GetCountry(IUnitOfWorks uow,int id)
        {
            return uow.Countries.getById(id);
        }

        public static Region GetRegion(IUnitOfWorks uow, int id)
        {
            return uow.Regions.getById(id);
        }
        
    }
}