﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using YouCompare.Data.Contracts;

namespace YouCompare.Data.Helpers
{
    public interface IRepositoryProvider
    {
        ActiveRecordBase ActiveRecordBase { get; set; }

        IRepository<T> GetRepositoryForEntityType<T>() where T : class;

        T GetRepository<T>(Func<ActiveRecordBase, object> factory = null) where T : class;
    }
}
