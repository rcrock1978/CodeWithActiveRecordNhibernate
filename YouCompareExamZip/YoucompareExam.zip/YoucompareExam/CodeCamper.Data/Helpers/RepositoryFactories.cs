﻿
using System;
using System.Collections.Generic;
using Castle.ActiveRecord;
using YouCompare.Data.Contracts;

namespace YouCompare.Data.Helpers
{
    public class RepositoryFactories
    {
        public RepositoryFactories()
        {
            _repositoryFactories = GetFactories(); 
        }

        private IDictionary<Type, Func<ActiveRecordBase, object>> GetFactories()
        {
            return new Dictionary<Type, Func<ActiveRecordBase, object>>
                {
                   {typeof(IProductsPurchased), dbContext => new ProductsPurchasedRepository(dbContext)}
                   //{typeof(IPersonsRepository), dbContext => new PersonsRepository(dbContext)},
                   //{typeof(ISessionsRepository), dbContext => new SessionsRepository(dbContext)},
                };
        }
        public Func<ActiveRecordBase, object> GetRepositoryFactoryForEntityType<T>() where T : class
        {
            return GetRepositoryFactory<T>() ?? DefaultEntityRepositoryFactory<T>(); 
        }

        protected virtual Func<ActiveRecordBase, object> DefaultEntityRepositoryFactory<T>() where T : class
        {
            return dbContext => new ActiveRecordRepository<T>(dbContext);
        }

        public Func<ActiveRecordBase, object> GetRepositoryFactory<T>()
        {
            Func<ActiveRecordBase, object> factory;
            _repositoryFactories.TryGetValue(typeof(T), out factory);
            return factory;
        }

        private readonly IDictionary<Type, Func<ActiveRecordBase, object>> _repositoryFactories;
    }
}
