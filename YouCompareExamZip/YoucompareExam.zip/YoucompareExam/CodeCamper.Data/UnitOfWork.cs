﻿using System;
using YouCompare.Data.Contracts;
using YouCompare.Data.Helpers;
using YouCompare.Model;

namespace YouCompare.Data
{
    public class UnitOfWork : IUnitOfWorks, IDisposable
    {
        public UnitOfWork(IRepositoryProvider repositoryProvider)
        {
            CreateDbContext();

            repositoryProvider.ActiveRecordBase = DbContext;
            RepositoryProvider = repositoryProvider; 
        }

        private ActiveRecordDbContext DbContext { get; set; }

        protected void CreateDbContext()
        {
            DbContext = new ActiveRecordDbContext();
        }

        protected IRepositoryProvider RepositoryProvider { get; set; }

        public IRepository<Country> Countries
        {
            get { return GetStandardRepo<Country>(); }
        }

        public IRepository<Region> Regions
        {
            get { return GetStandardRepo<Region>(); }
        }

        public IRepository<Customer> Customers
        {
            get { return GetStandardRepo<Customer>(); }
        }

        public IRepository<Product> Products
        {
            get { return GetStandardRepo<Product>(); }
        }

        public IRepository<Order> Orders
        {
            get { return GetStandardRepo<Order>(); }
        }

        public IRepository<OrderDetail> OrderDetails
        {
            get { return GetStandardRepo<OrderDetail>(); }
        }

        public IProductsPurchased ProductsPurchased
        {
            get { return GetRepo<IProductsPurchased>(); }
        }

        private IRepository<T> GetStandardRepo<T>() where T : class
        {
            return RepositoryProvider.GetRepositoryForEntityType<T>();
        }

        private T GetRepo<T>() where T : class
        {
            return RepositoryProvider.GetRepository<T>();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                DbContext = null;
            }
        }



    }
}
