﻿using System;
using System.Configuration;
using Castle.ActiveRecord;
using Castle.ActiveRecord.Framework;
using YouCompare.Model;

namespace YouCompare.Data
{
    public class ActiveRecordDbContext : ActiveRecordBase
    {
        public ActiveRecordDbContext()
        {
            ActiveRecordStarter.ResetInitializationFlag();

            ActiveRecordStarter.Initialize(GetConfigSource(),
                typeof(Country),
                typeof(Region),
                typeof(Customer),
                typeof(Order),
                typeof(Product),
                typeof(OrderDetail));

            //For Testing
            //ActiveRecordStarter.Initialize(GetConfigSource(),
            //    typeof(Country),
            //    typeof(Region),
            //    typeof(Customer),
            //    typeof(Order),
            //    typeof(Product),
            //    typeof(OrderDetail));
            //Recreate();
        }


        public static IConfigurationSource GetConfigSource()
        {
            return ConfigurationManager.GetSection("activerecord") as IConfigurationSource;
        }

        public static void Recreate()
        {
            ActiveRecordStarter.CreateSchema();
        }

        public virtual void Init()
        {
            ActiveRecordStarter.ResetInitializationFlag();
        }

        public virtual void Drop()
        {
            //UnComment For Testting

            //try
            //{
            //    ActiveRecordStarter.DropSchema();
            //}
            //catch (Exception)
            //{

            //}
        }
    }
}
