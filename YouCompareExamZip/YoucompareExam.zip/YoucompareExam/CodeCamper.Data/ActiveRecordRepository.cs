﻿using System;
using System.Collections.Generic;
using System.Linq;
using Castle.ActiveRecord;
using YouCompare.Data.Contracts;

namespace YouCompare.Data
{
    public class ActiveRecordRepository<T> : ActiveRecordBase<T>, IRepository<T> where T : class 
    {
        public ActiveRecordRepository(ActiveRecordBase activeRecordBase)
        {
            if (activeRecordBase == null)
                throw new ArgumentNullException("activeRecordBase");

            ActiveRecordContext = activeRecordBase;
        }

        protected ActiveRecordBase ActiveRecordContext { get; set; }

        public virtual IQueryable<T> getAll()
        {
            try
            {
                return (IQueryable<T>)ActiveRecordMediator.FindAll(typeof(T)).AsQueryable();
            }
            catch (Exception)
            {
                return null;
            }

        }

        public virtual T getById(int id)
        {
            try
            {
               return (T)ActiveRecordMediator.FindByPrimaryKey(typeof(T), id);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public virtual IList<T> getListById(string property, object id)
        {
            try
            {
                var getListed = (IList<T>)ActiveRecordMediator.FindAllByProperty(typeof(T), property, id);
                return getListed;
            }
            catch (Exception)
            {
              return null;
            }

        }

        public virtual void add(T entity)
        {
           ActiveRecordMediator.Create(entity);
        }

        public virtual void update(T entity)
        {
            ActiveRecordMediator.Update(entity);
        }

        public virtual void delete(T entity)
        {
            ActiveRecordMediator.Delete(entity);
        }

        public virtual void delete(int id)
        {
            dynamic entity = getById(id);
            if (entity == null) return;
            delete(entity);
        }
    }
}
