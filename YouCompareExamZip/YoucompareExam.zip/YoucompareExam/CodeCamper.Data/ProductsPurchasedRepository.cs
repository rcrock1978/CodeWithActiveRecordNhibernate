﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Castle.ActiveRecord;
using YouCompare.Data.Contracts;
using YouCompare.Model;

namespace YouCompare.Data
{
    public class ProductsPurchasedRepository : ActiveRecordRepository<ProductPurchased>, IProductsPurchased
    {
        public ProductsPurchasedRepository(ActiveRecordBase activeRecordBase)
            : base(activeRecordBase)
        {
            
        }

        public IQueryable<ProductPurchased> GetProductsPurchasedbyCustomerId(int id)
        {
            Func<int, Object> fromcustomer = GetCustomerDetails;


            dynamic customer = fromcustomer(id);
            dynamic orders = customer.Orders;
            var purchasedProductsList = new List<OrderDetail>();
            foreach (var yorder in orders)
            {
                Func<int, Object> order = GetOrderDetails; 
                dynamic orderDetails = order(yorder.OrderId);

                foreach (var orderDetail in orderDetails.OrderDetails)
                {
                    Func<int, Object> orderdetails = GetOrderDetailDetails;
                    dynamic purchased = orderdetails(orderDetail.Id);
                    purchasedProductsList.Add(purchased);
                }
            };

            Func<int, Order> byOrder = GetOrderDetails;

            Func<int, Product> byProduct = GetProductDetails;

            var result = (from pList in purchasedProductsList
                select new ProductPurchased()
                {
                  Companyname = customer.CompanyName,
                  Contact = customer.ContactName,
                  Region = (customer.Region).RegionName,
                  Country = (customer.Country).CountryName,
                  ProDuctname = (byProduct((pList.ProductId).ProductId)).ProductName,
                  Price = (byProduct((pList.ProductId).ProductId)).UnitPrice,
                  PurchasedDate = (byOrder((pList.OrderId).OrderId)).OrderDate
                })
            .AsQueryable();

            return result;

        }

        private static OrderDetail GetOrderDetailDetails(int id)
        {
            return (OrderDetail)ActiveRecordMediator.FindByPrimaryKey(typeof(OrderDetail), id);
        }

        private static Order GetOrderDetails(int id)
        {
            return (Order)ActiveRecordMediator.FindByPrimaryKey(typeof(Order), id);
        }

        private static Customer GetCustomerDetails(int id)
        {
            return (Customer)ActiveRecordMediator.FindByPrimaryKey(typeof(Customer), id);
        }

        private static Product GetProductDetails(int id)
        {
            return (Product)ActiveRecordMediator.FindByPrimaryKey(typeof(Product), id);
        }

      
    }
}
