﻿
using Castle.ActiveRecord;

namespace YouCompare.Model
{
    [ActiveRecord("Region")]
    public class Region
    {
        public Region()
        {
            
        }

        [PrimaryKey(PrimaryKeyType.Identity)]
        public int RegionId { get; set; }

        [Property(Unique = true, NotNull = true)]
        public string RegionName { get; set; }
    }
}
