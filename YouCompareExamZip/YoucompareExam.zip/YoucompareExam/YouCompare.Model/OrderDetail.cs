﻿
using Castle.ActiveRecord;
using Iesi.Collections;

namespace YouCompare.Model
{
    [ActiveRecord("OrderDetail")]
    public class OrderDetail
    {
        public OrderDetail()
        {
            
        }

        [PrimaryKey(PrimaryKeyType.Identity)]
        public int Id { get; set; } 

        [BelongsTo("OrderId")]
        public Order OrderId { get; set; }

        [BelongsTo("ProductId")]
        public Product ProductId { get; set; }

        [Property]
        public decimal UnitPrice { get; set; }

        [Property]
        public int Quantity { get; set; }

    }
}
