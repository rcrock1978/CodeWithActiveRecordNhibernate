﻿
using System.Collections.Generic;
using Castle.ActiveRecord;

namespace YouCompare.Model
{
    [ActiveRecord("Customer")]
    public class Customer
    {
        public Customer()
        {
            
        }

        [PrimaryKey(PrimaryKeyType.Identity)]
        public int CustomerId { get; set; }

        [Property]
        public string CompanyName { get; set; }

        [Property]
        public string ContactName { get; set; }

        [Property]
        public string Address { get; set; }

        [Property]
        public string City { get; set; }

        [BelongsTo("RegionId")]
        public Region Region { get; set; }

        [Property]
        public int PostalCode { get; set; }

        [BelongsTo("CountryId")]
        public Country Country { get; set; }

        [Property]
        public string Phone { get; set; }

        [HasMany(Table = "Order", Fetch = FetchEnum.Select, ColumnKey = "CustomerId")]
        public IList<Order> Orders { get; set; }
    }

}
