﻿
using Castle.ActiveRecord;

namespace YouCompare.Model
{
    [ActiveRecord("Country")]
    public class Country
    {
        public Country()
        {
            
        }

        [PrimaryKey(PrimaryKeyType.Identity)]
        public int CountryId { get; set; }

        [Property(Unique = true, NotNull = true)]
        public string CountryName { get; set; }
    }
}
