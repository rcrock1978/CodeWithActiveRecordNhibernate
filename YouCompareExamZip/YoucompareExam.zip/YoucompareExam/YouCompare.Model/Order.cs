﻿using System;
using System.Collections.Generic;
using Castle.ActiveRecord;

namespace YouCompare.Model
{
    [ActiveRecord("Orders")]
    public class Order
    {
        public Order()
        {
            
        }

        [PrimaryKey(PrimaryKeyType.Identity)]
        public int OrderId { get; set; }

        [BelongsTo("CustomerId")]
        public Customer CustomerId { get; set; }

        [Property]
        public DateTime OrderDate { get; set; }

        [Property]
        public DateTime RequiredDate { get; set; }

        [HasMany(Table = "OrderDetail", Fetch = FetchEnum.Join, ColumnKey = "OrderId")]
        public IList<OrderDetail> OrderDetails { get; set; }

    }
}
