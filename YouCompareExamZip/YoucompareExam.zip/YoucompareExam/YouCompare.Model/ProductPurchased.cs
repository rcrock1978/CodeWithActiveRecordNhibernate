﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YouCompare.Model
{
    public class ProductPurchased
    {
        public string Companyname { get; set; }

        public string Contact { get; set; }

        public string Region { get; set; }

        public string Country { get; set; }

        public string ProDuctname { get; set; }

        public decimal Price { get; set; }

        public DateTime PurchasedDate { get; set; }
    }
}
