﻿
using Castle.ActiveRecord;
using Iesi.Collections;

namespace YouCompare.Model
{
    [ActiveRecord("Product")]
    public class Product
    {
        public Product()
        {
            
        }

        [PrimaryKey(PrimaryKeyType.Identity)]
        public int ProductId { get; set; }

        [Property]
        public string ProductName { get; set; }

        [Property]
        public decimal UnitPrice { get; set; }

 }
}
