﻿using Ninject.Modules;
using YouCompare.Data.Contracts;
using YouCompare.Data.Helpers;

namespace YouCompare.Data.Test
{
    public class ConfigModule : NinjectModule
    {
        public override void Load()
        {
            Kernel.Bind<RepositoryFactories>().To<RepositoryFactories>()
                .InSingletonScope();

            Kernel.Bind<IRepositoryProvider>().To<RepositoryProvider>();

            Kernel.Bind<IUnitOfWorks>().To<UnitOfWork>();
        }
    }
}
