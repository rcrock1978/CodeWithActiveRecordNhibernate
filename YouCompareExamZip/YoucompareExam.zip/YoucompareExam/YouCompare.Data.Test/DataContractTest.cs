﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using Ninject;
using YouCompare.Data.Contracts;
using YouCompare.Model;

namespace YouCompare.Data.Test
{
    [TestFixture]
    public class DataContractTest
    {
        public StandardKernel Kernel { get; set; }

        [SetUp]
        public void Init()
        {
            var kernel = new StandardKernel(new ConfigModule());
            Kernel = kernel;
        }

        [Test]
        public void Add_Test()
        {
            var addOrder = Kernel.Get<UowInjection>();
            addOrder.TestAdd();
        }

        [Test]
        public void Get_Customer_Test()
        {
            var getCustomer = Kernel.Get<UowInjection>();
            Customer objectCustomer = getCustomer.ObjectCustomer();
            Customer fromDatabase = getCustomer.From_DataBase_GetCustomer();
            Assert.IsNotNull(objectCustomer);
            Assert.IsNotNull(fromDatabase);
            Assert.AreEqual(objectCustomer.CustomerId, fromDatabase.CustomerId);
        }

        [Test]
        public void Get_Region_by_id_Test()
        {
            var getRegion = Kernel.Get<UowInjection>();
            getRegion.AddRegion();
            var region = getRegion.GetRegionById(1);
            Assert.IsNotNull(region);
        }

        [Test]
        public void Get_Regions_Test()
        {
            var getRegions = Kernel.Get<UowInjection>();
            getRegions.AddRegion();
            var region = getRegions.GetRegions();
            Assert.IsNotNull(region);
            Assert.AreEqual(1, region.Count());
        }

        [Test]
        public void Get_Country_by_id_Test()
        {
            var getCountry = Kernel.Get<UowInjection>();
            getCountry.AddCountry();
            var country = getCountry.GetCountryById(2);
            Assert.IsNotNull(country);
        }

        [Test]
        public void Get_Countries_Test()
        {
            var getCountries = Kernel.Get<UowInjection>();
            getCountries.AddCountry();
            var countries = getCountries.GetCountry();
            Assert.IsNotNull(countries);
            Assert.AreEqual(2, countries.Count());
        }

        [Test]
        public void Update_Customer_Test()
        {
            var updateCustomer = Kernel.Get<UowInjection>();
            var customer = updateCustomer.ObjectCustomer();
            Assert.IsNotNull(customer);
            var country = updateCustomer.GetCountryById(2);
            Assert.IsNotNull(country);
            var newCustomer = new Customer()
            {
                Address = customer.Address,
                City = customer.City,
                ContactName = customer.ContactName,
                CompanyName = "Microsourcing Philippines",
                Country = country,
                Phone = customer.Phone,
                CustomerId = customer.CustomerId,
                PostalCode = customer.PostalCode,
                Region = customer.Region,
                Orders = customer.Orders
            };
            Assert.IsNotNull(newCustomer);
            updateCustomer.UpdateCustomer(newCustomer);
            var updatedCustomer = updateCustomer.GetCustomerById(customer.CustomerId);
            Assert.IsNotNull(updatedCustomer);
            Assert.AreEqual(updatedCustomer.Address, newCustomer.Address);
            Assert.AreEqual(updatedCustomer.CompanyName, newCustomer.CompanyName);
            Assert.AreEqual(updatedCustomer.ContactName, newCustomer.ContactName);
            Assert.AreEqual(updatedCustomer.City, newCustomer.City);
            Assert.AreEqual(updatedCustomer.Phone, newCustomer.Phone);
            Assert.AreEqual(updatedCustomer.Country.CountryId,country.CountryId);
            Assert.AreEqual(updatedCustomer.Country.CountryName, country.CountryName);
            Assert.AreEqual(updatedCustomer.CustomerId, newCustomer.CustomerId);
            Assert.AreEqual(updatedCustomer.PostalCode, newCustomer.PostalCode);
            var region = updateCustomer.GetRegionById(1);
            Assert.AreEqual(updatedCustomer.Region.RegionId, region.RegionId);
            Assert.AreEqual(updatedCustomer.Region.RegionName, region.RegionName);
        }

        [Test]
        public void Delete_Customer_No_Order_Test()
        {
            var deleteCustomer = Kernel.Get<UowInjection>();
            var customer = deleteCustomer.ObjectCustomer();
            Assert.IsNotNull(customer);
            deleteCustomer.DeleteCustomer(customer);
            customer = deleteCustomer.GetCustomerById(customer.CustomerId);
            Assert.IsNull(customer);
        }

        [Test]
        public void Delete_Customer_with_Order_Test()
        {
            var deleteCustomer = Kernel.Get<UowInjection>();
            deleteCustomer.CreateSampleData();
            var customer = deleteCustomer.GetCustomerById(1);
            Assert.IsNotNull(customer);
            deleteCustomer.DeleteCustomer(customer);
            customer = deleteCustomer.GetCustomerById(customer.CustomerId);
            Assert.IsNull(customer);
        }

        [Test]
        public void Delete_OrderDetail_and_Order_Test()
        {
            var deleteOrderDetailOrder = Kernel.Get<UowInjection>();
            deleteOrderDetailOrder.CreateSampleData();
            var order = deleteOrderDetailOrder.From_DataBase_GetOrder();
            Assert.IsNotNull(order);
            var orderDetail = deleteOrderDetailOrder.From_DataBase_ListOfGetOrderDetail(order);
            Assert.IsNotNull(orderDetail);
            foreach (var detail in orderDetail)
            {
                deleteOrderDetailOrder.Delete_OrderDetail(detail);
                var findOrderDetail = deleteOrderDetailOrder.GetOrderDetailById(detail.Id);
                Assert.IsNull(findOrderDetail);
            }

            deleteOrderDetailOrder.Delete_Order(order);
            var findOrder = deleteOrderDetailOrder.GetOrderById(order.OrderId);
            Assert.IsNull(findOrder);
        }

        [Test]
        public void Get_Products_Purchased_by_Customers_Test()
        {
            var productPurchased = Kernel.Get<UowInjection>();
            productPurchased.CreateSampleData();
            var newProducts = productPurchased.GetProductPurchased();
            Assert.IsNotNull(newProducts);
            Assert.AreEqual(2, newProducts.Count());
        }

        [Test]
        public void InitData()
        {
            var init = Kernel.Get<UowInjection>();
            init.CreateSampleData();
        }
    }

    public class UowInjection
    {
        public UowInjection()
        {
            Region = new Region();
            Country = new Country();
            Customer = new Customer();
            Order = new Order();
        }

        protected IUnitOfWorks Uow { get; set; }

        public UowInjection(IUnitOfWorks unitOfWorks)
        {
            this.Uow = unitOfWorks;
        }

        private Region Region { get; set; }

        private Country Country { get; set; }

        private Customer Customer { get; set; }

        private List<Product> Product { get; set; }

        private Order Order { get; set; }

        public void AddRegion()
        {
            var region = new Region()
            {
                RegionName = "NCR"
            };

            Uow.Regions.add(region);
            Region = region;
        }

        public void AddCountry()
        {
            var country = new Country()
            {
                CountryName = "Philippines"
            };

            Uow.Countries.add(country);
            Country = country;

            country = new Country()
            {
                CountryName = "Australia"
            };

            Uow.Countries.add(country);

        }

        public void AddCustomer()
        {
            var customer = new Customer()
            {
                CompanyName = "SSI Philippines Inc",
                ContactName = "Perez Hilton",
                Address = "Serna St., Pajo",
                City = "Lapu lapu City",
                Country = Country,
                PostalCode = 1300,
                Region = Region,
                Phone = "12345566"
            };

            Uow.Customers.add(customer);
            Customer = customer;
        }

        public void AddProducts()
        {
                Product = new List<Product>();
                List<Product> products = new List<Product>()
                {
                    new Product()
                    {
                        ProductName = "Chai Chang",
                        UnitPrice = (decimal) 100.RandomThis()
                    },
                    new Product()
                    {
                        ProductName = "Aniseed Syrup",
                        UnitPrice = (decimal) 100.RandomThis()
                    },
                    new Product()
                    {
                        ProductName = "Chef Anton's Cajun Seasoning",
                        UnitPrice = (decimal) 100.RandomThis()
                    },
                    new Product()
                    {
                        ProductName = "Grandma's Boysenberry Spread",
                        UnitPrice = (decimal) 100.RandomThis()
                    },
                    new Product()
                    {
                        ProductName = "Northwoods Cranberry Sauce",
                        UnitPrice = (decimal) 100.RandomThis()
                    }

                };

            foreach (Product product in products)
            {
                Uow.Products.add(product);
                Product.Add(product);
            }
        }

        public void AddOrder()
        {
            var order = new Order()
            {
                CustomerId = Customer,
                OrderDate = DateTime.Now,
                RequiredDate = DateTime.Now.AddDays(10.RandomThis())
            };

            Uow.Orders.add(order);
            Order = order;
        }

        public void OrderDetail()
        {
            var orderDetail = new OrderDetail()
            {
                OrderId = Order,
                ProductId = GetProductById(1),
                Quantity = 10.RandomThis(),
                UnitPrice = 300.RandomThis()
            };

            Uow.OrderDetails.add(orderDetail);

            orderDetail = new OrderDetail()
            {
                OrderId = Order,
                ProductId = GetProductById(4),
                Quantity = 10.RandomThis(),
                UnitPrice = 300.RandomThis()
            };

            Uow.OrderDetails.add(orderDetail);
        }

        public Product GetProductById(int id)
        {
            return Uow.Products.getById(id);
        }

        public Order GetOrderById(int id)
        {
            return Uow.Orders.getById(id);
        }

        public Customer GetCustomerById(int id)
        {
            return Uow.Customers.getById(id);
        }

        public Country GetCountryById(int id)
        {
            return Uow.Countries.getById(id);
        }

        public Region GetRegionById(int id)
        {
            return Uow.Regions.getById(id);
        }

        public IQueryable<Region> GetRegions()
        {
            return Uow.Regions.getAll();
        }

        public IQueryable<Country> GetCountry()
        {
            return Uow.Countries.getAll();
        }

        public OrderDetail GetOrderDetailById(int id)
        {
            return Uow.OrderDetails.getById(id);
        }

        public IList<OrderDetail> GetOrderDetailById(string property, object id)
        {
            return Uow.OrderDetails.getListById(property, id);
        }

        public void TestAdd()
        {
            AddRegion();
            AddCountry();
            AddCustomer();
            AddProducts();
            AddOrder();
            OrderDetail();
        }

        public Customer ObjectCustomer()
        {
            AddRegion();
            AddCountry();
            AddCustomer();
            return Customer;
        }

        public void DeleteCustomer(Customer customer)
        {
            Uow.Customers.delete(customer);
        }

        public void CreateSampleData()
        {
            AddRegion();
            AddCountry();
            AddCustomer();
            AddProducts();
            AddOrder();
            OrderDetail();
        }

        public Order From_DataBase_GetOrder()
        {
            return GetOrderById(1);
        }

        public IList<OrderDetail> From_DataBase_ListOfGetOrderDetail(Order order)
        {
            return GetOrderDetailById("OrderId", order);
        }

        public void Delete_Order(Order order)
        {
            Uow.Orders.delete(order.OrderId);
        }

        public void Delete_OrderDetail(OrderDetail orderDetail)
        {
            Uow.OrderDetails.delete(orderDetail.Id);
        }

        public void UpdateCustomer(Customer customer)
        {
            Uow.Customers.update(customer);
        }
  
        public Customer From_DataBase_GetCustomer()
        {
            return Uow.Customers.getById(1);
        }

        public IQueryable<ProductPurchased> GetProductPurchased()
        {
            return Uow.ProductsPurchased.GetProductsPurchasedbyCustomerId(1).AsQueryable();
        }


    }

    public static class ExtensionMethods
    {
        static Random _r = new Random();
        public static int RandomThis(this int value)
        {
            int n = _r.Next(1,value);
  
            return n;
        }

        public static int RandomProduct(this int value)
        {
            int n = _r.Next(1, value);

            return n;
        }
    }
}
