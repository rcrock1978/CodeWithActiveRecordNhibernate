﻿
using System;
using System.Configuration;
using Castle.ActiveRecord;
using Castle.ActiveRecord.Framework;
using NUnit.Framework;

namespace YouCompare.AbstractActiveRecord.ConfigureTest
{
    public abstract class AbstractActiveRecordTest
    {
        public static IConfigurationSource GetConfigSource()
        {
            return ConfigurationManager.GetSection("activerecord") as IConfigurationSource;
        }

        public static void Recreate()
        {
            ActiveRecordStarter.CreateSchema();
        }

        [SetUp]
        public virtual void Init()
        {
            ActiveRecordStarter.ResetInitializationFlag();
        }

        [TearDown]
        public virtual void Drop()
        {
            try
            {
                ActiveRecordStarter.DropSchema();
            }
            catch (Exception)
            {

            }
        }
    }
}
