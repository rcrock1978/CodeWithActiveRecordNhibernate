﻿using Castle.ActiveRecord;
using NUnit.Framework;
using YouCompare.AbstractActiveRecord.ConfigureTest;

namespace YouCompare.Model.Test
{
    [TestFixture]
    public class MappingTest : AbstractActiveRecordTest
    {
        [Test]
        public void Test_Invalid_Mapping()
        {
            ActiveRecordStarter.Initialize(GetConfigSource(), typeof(Country), typeof(Region), typeof(Customer), typeof(Order), typeof(Product), typeof(OrderDetail));
            Recreate();
        }
    }
}
