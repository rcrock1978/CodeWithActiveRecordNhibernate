﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Castle.MonoRail.Framework;

namespace YouCompare.Web.Controllers
{
    public class MenuController : SmartDispatcherController
    {
        public void HeaderMenu()
        {
            RenderView("headermenu");
        }
    }
}