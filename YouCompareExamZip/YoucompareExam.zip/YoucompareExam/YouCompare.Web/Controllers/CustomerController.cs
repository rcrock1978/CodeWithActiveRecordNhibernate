﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Castle.MonoRail.Framework;
using Castle.MonoRail.Framework.Helpers;

namespace YouCompare.Web.Controllers
{
    [Layout("default"), Rescue("generalerror"), Helper(typeof(JSONHelper), "Json")]
    public class CustomerController : SmartDispatcherController
    {
        public void Index()
        {
            
        }

        public void Create()
        {

        }



    }
}