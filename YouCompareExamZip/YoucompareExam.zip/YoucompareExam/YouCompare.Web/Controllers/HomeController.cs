﻿using Castle.MonoRail.Framework;

namespace YouCompare.Web.Controllers
{
    [Layout("default")]
    public class HomeController : SmartDispatcherController
    {
        public void Index()
        {
            PropertyBag["messages"] = new[]
                                         {
                                             "Hello everyone!",
                                             "This is my first screencast.",
                                             "Welcome to castlecasts!"
                                         };
        }
    }
}