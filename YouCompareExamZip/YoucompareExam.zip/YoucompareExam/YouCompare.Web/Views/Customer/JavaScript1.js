﻿
(function($) {
    $(document).ready(function() {
        $('#create').bind('submit', function(e) {
            e.preventDefault();
            var company = $("#company").val();
            var name = $("#name").val();
            var address = $("#address").val();
            var city = $("#city").val();
            var region = $("#region").val();
            var postalcode = $("#postalcode").val();
            var country = $("#country").val();
            var phone = $("#phone").val();
            $.ajax({
                url: "http://localhost:11301/api/customers",
                type: "Post",
                data: JSON.stringify([address, city, company,name,country,phone,postalcode, region]), 
                contentType: 'application/json; charset=utf-8',
                success: function (data) { },
                error: function () { alert('error'); }
            });
        });
})(jQuery);

$(document).ready(function() {
    $('#form-id').bind('submit', function(e) {
        e.preventDefault();
    });


});
    <script type="text/javascript">
                       $(document).ready(function () {
                           $('#form-id').bind('submit', function () { 
                               var company = $("#company").val();
                               var name = $("#name").val();
                               var address = $("#address").val();
                               var city = $("#city").val();
                               var region = $("#region").val();
                               var postalcode = $("#postalcode").val();
                               var country = $("#country").val();
                               var phone = $("#phone").val();
                               $.ajax({
                                   url: "http://localhost:11301/api/customers",
                                   type: "Post",
                                   data: JSON.stringify([address, city, company,name,country,phone,postalcode, region]), 
                                   contentType: 'application/json; charset=utf-8',
                                   success: function (data) { },
                                   error: function () { alert('error'); }
                               });
              
                           });
                       });
</script>