﻿using System.Collections.Generic;
using System.Linq;

namespace YouCompare.Data.Contracts
{
    public interface IRepository<T> where T : class 
    {
        IQueryable<T> getAll();
        T getById(int id);
        IList<T> getListById(string property, object id); 
        void add(T entity);
        void update(T entity);
        void delete(T entity);
        void delete(int id);
    }
}
