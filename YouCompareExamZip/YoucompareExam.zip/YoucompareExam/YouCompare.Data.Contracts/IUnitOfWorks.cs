﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using YouCompare.Model;

namespace YouCompare.Data.Contracts
{
    public interface IUnitOfWorks
    {
        IRepository<Country> Countries { get; } 
        IRepository<Region> Regions { get; }
        IRepository<Customer> Customers { get; }
        IRepository<Product> Products { get; }
        IRepository<Order> Orders { get; }
        IRepository<OrderDetail> OrderDetails { get; }
        IProductsPurchased ProductsPurchased { get; }
    }
}
