﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using YouCompare.Model;

namespace YouCompare.Data.Contracts
{
    public interface IProductsPurchased : IRepository<ProductPurchased>
    {
        IQueryable<ProductPurchased> GetProductsPurchasedbyCustomerId(int id);
    }
}
